import DetailPresenter from "../../presenters/detail-presenter";
import { parseActivePathname } from "../../routes/url-parser";

export default class DetailPage {
    constructor() {
        this.presenter = new DetailPresenter(this);
    }

    async render() {
        return `
            <section class="detail-page container">
                <a href="#/home" class="back-button">
                <span class="material-symbols-outlined">arrow_back</span>
                </a>
                <div id="story-detail" class="story-detail"></div>
                <div id="map" class="story-map"></div>
            </section>
        `;
    }

    async afterRender() {
        const { id } = parseActivePathname();
        await this.presenter.loadStoryDetail(id);

    }

    showStoryDetail(story) {
        const detailElement = document.getElementById('story-detail');
        detailElement.innerHTML = `
            <div class="story-header">
                <h2>${story.name}'s Story</h2>
                <p class="story-date">${new Date(story.createdAt).toLocaleDateString()}</p>
            </div>
            <div class="story-content">
                <img src="${story.photoUrl}" alt="${story.name}'s story" class="story-image">
                <p class="story-description">${story.description}</p>
            </div>
        `;
    }

    showNoMap() {
        const mapElement = document.getElementById('map');
        mapElement.innerHTML = `
            <div class="no-map-message">
                <span class="material-symbols-outlined">location_off</span>
                <p>Story ini tidak memiliki data lokasi peta</p>
            </div>
        `;
    }

    showError(message) {
        const detailElement = document.getElementById('story-detail');
        detailElement.innerHTML = `
            <div class="error-message">
                <p>${message}</p>
                <button onclick="window.location.hash = '#/home'">Back to Home</button>
            </div>
        `;
    }
}