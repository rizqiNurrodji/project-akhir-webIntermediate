self.addEventListener('push', function (event) {
  if (event.data) {
    const data = event.data.json();

    const title = data.title || 'Notifikasi Baru';
    const options = {
      body: data.options?.body || 'Ada pembaruan cerita.',
    };

    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  }
});