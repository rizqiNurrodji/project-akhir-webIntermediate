import { addStory } from "../data/api.js";

export default class AddStoryPresenter {
    constructor(view) {
        this.view = view;
    }

    async submitStory({description, image, lat, lon}) {
        try {
            await addStory({
                description: description,
                photo: image,
                lat: lat,
                lon: lon
            });
            alert('Story added successfully!');
            window.location.href = '#/home';
        } catch (error) {
            alert('Failed to add story. Please try again.');
        }
    }
}